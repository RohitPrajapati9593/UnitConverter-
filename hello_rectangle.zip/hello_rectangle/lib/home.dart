// import 'package:flutter/material.dart';
//
// const _padding = EdgeInsets.all(16.0);
//
// void main() {
//   runApp(
//     MaterialApp(
//       debugShowCheckedModeBanner: false,
//       home: Scaffold(
//         appBar: AppBar(
//           title: Text('Hello Rectagle'),
//         ),
//         body: HelloRectangle(),
//       ),
//     ),
//   );
// }
//
// class HelloRectangle extends StatelessWidget {
//   final _backgroundColor = Colors.teal;
//
//   @override
//   Widget build(BuildContext context) {
//     return Center(
//       child: Container(
//         padding: _padding,
//         color: Colors.greenAccent,
//         height: 400.0,
//         width: 300.0,
//         child: Padding(
//           padding: _padding,
//           child: Text(
//             'Hello!',
//             style: TextStyle(fontSize: 40.0),
//             textAlign: TextAlign.center,
//           ),
//         ),
//       ),
//     );
//   }
// }
//
// var container = Container(
//   color: Colors.orange,
//   width: 300.0,
//   height: 400.0,
//   margin: EdgeInsets.all(16.0),
//   child: Column(
//     children: <Widget>[
//       Text('Hello'),
//       Text('Hello'),
//       Text('Hello'),
//       Text('Hello'),
//     ],
//   ),
// );


//TODO:: Column have childern widget
// var containr = Column(
//   children: <Widget>[
//     Text ('Hello'),
//     Text ('Hello'),
//     Text ('Hello'),
//     Text ('Hello')
//
//   ],
// );


//TODO:: Container have child widget
// var container =Container(
//   color: Colors.orange,
//   width: 300.0,
//   height: 400.0,
//   margin: EdgeInsets.all(16.0),
//   child:Text('Hello!'),
// );
