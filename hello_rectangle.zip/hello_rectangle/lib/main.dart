import 'package:flutter/material.dart';
import 'package:hello_rectangle/category_route.dart';
import 'package:flutter/cupertino.dart';
// Widget helloRectangle() {
//   return Container(
//     color: Colors.teal,
//   );
// }


void main() {
  runApp(const UnitConverterApp());
}

/// This widget is the root of our application.
///
/// The first screen we see is a list [Categories], each of which
/// has a list of [Unit]s.
class UnitConverterApp extends StatelessWidget {
  const UnitConverterApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Unit Converter',
      theme: ThemeData(
        fontFamily: 'Raleway',
        textTheme: Theme.of(context).textTheme.apply(
          bodyColor: Colors.black,
          displayColor: Colors.grey[600],
        ),
        // This colors the [InputOutlineBorder] when it is selected
        primaryColor: Colors.grey[500],
        textSelectionTheme:
        TextSelectionThemeData(selectionHandleColor: Colors.green[500]),
      ),
      home: const CategoryRoute(),
    );
  }
}
// import 'package:flutter/material.dart';
//
// // You can use a relative import, i.e. `import 'category.dart;'` or
// // a package import, as shown below.
// // More details at http://dart-lang.github.io/linter/lints/avoid_relative_lib_imports.html
// import 'package:solution_02_category_widget/category.dart';
//
// const _categoryName = 'Cake';
// const _categoryIcon = Icons.cake;
// const _categoryColor = Colors.green;
//
// /// The function that is called when main.dart is run.
// void main() {
//   runApp(const UnitConverterApp());
// }
//
// /// This widget is the root of our application.
// /// Currently, we just show one widget in our app.
// class UnitConverterApp extends StatelessWidget {
//   const UnitConverterApp({Key? key}) : super(key: key);
//
//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       debugShowCheckedModeBanner: false,
//       title: 'Unit Converter',
//       home: Scaffold(
//         backgroundColor: Colors.green[100],
//         body: const Center(
//           child: Category(
//             name: _categoryName,
//             color: _categoryColor,
//             iconLocation: _categoryIcon,
//           ),
//         ),
//       ),
//     );
//   }
// }


//
// var brandColors= ColorsSwatch(0xFF285F4,{
// 'brandBlue'  :Color(0xFF444285F4),
// });