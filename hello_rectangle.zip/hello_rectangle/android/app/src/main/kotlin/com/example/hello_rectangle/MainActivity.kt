package com.example.hello_rectangle

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
